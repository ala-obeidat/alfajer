
function moveToCall(){
    window.location.href=window.location.origin+'call.html';
}